import mongoose from "mongoose"
import orderModel from "../models/orderModel.js"
import productModel from "../models/product.model.js"

export const placeOrder = async (req, res) => {
    const session = await mongoose.startSession()
    session.startTransaction()

    try {
        const { billingDetails, cartItems, paymentMethod } = req.body
        const userId = req.user._id

        if (!cartItems || cartItems.length === 0) {
            await session.abortTransaction()
            session.endSession()
            return res.json({ success: false, message: "Cart is empty" })
        }

        let totalAmount = 0
        const orderItems = []

        for (const item of cartItems) {
            const product = await productModel
                .findById(item.product)
                .session(session)

            if (!product) {
                throw new Error("Product not found")
            }

            if (product.stock < item.quantity) {
                throw new Error(
                    `Only ${product.stock} left for ${product.title}`
                )
            }

            // Reduce stock
            product.stock -= item.quantity
            await product.save({ session })

            orderItems.push({
                product: product._id,
                title: product.title,
                price: item.price,
                image: product.images[0],
                selectedSize: item.selectedSize || null,
                quantity: item.quantity,
            })

            totalAmount += item.price * item.quantity
        }

        const order = await orderModel.create(
            [
                {
                    user: userId,
                    orderItems,
                    billingDetails,
                    paymentMethod,
                    totalAmount,
                },
            ],
            { session }
        )

        await session.commitTransaction()
        session.endSession()

        return res.json({
            success: true,
            message: "Order placed successfully",
            order: order[0],
        })
    } catch (error) {
        await session.abortTransaction()
        session.endSession()

        return res.json({
            success: false,
            message: error.message,
        })
    }
}
export const getMyOrders = async (req, res) => {
    try {
        const userId = req.user._id

        const orders = await orderModel.find({ user: userId }).sort({ createdAt: -1 })

        return res.json({
            success: true,
            orders,
        })
    } catch (error) {
        return res.json({ success: false, message: error.message })
    }
}

export const getOrderById = async (req, res) => {
    try {
        const userId = req.user._id
        const { orderId } = req.params

        const order = await orderModel.findOne({
            _id: orderId,
            user: userId,
        })

        if (!order) {
            return res.status(404).json({
                success: false,
                message: "Order not found",
            })
        }

        return res.json({
            success: true,
            order,
        })
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message,
        })
    }
}