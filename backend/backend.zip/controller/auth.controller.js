import userModel from "../models/user.model.js";
import bcrypt from "bcryptjs"
import generateToken from "../utils/generateToken.js";

export const register = async (req, res) => {
    try {
        const { name, email, password } = req.body

        if (!name || !email || !password) {
            return res.json({ success: false, message: "All fields are required" });
        }

        const exists = await userModel.findOne({ email });

        if (exists) {
            return res.json({ success: false, message: "User already exists" });
        }

        const hashPassword = await bcrypt.hash(password, 10)

        await userModel.create({
            name,
            email,
            password: hashPassword
        })

        return res.json({ success: true, message: "Registered successfully" });

    } catch (error) {
        console.log(error);
        return res.json({ success: false, message: error.message });
    }
}

export const login = async (req, res) => {
    try {
        console.log("REQ BODY:", req.body);

        const { email, password } = req.body;

        if (!email, !password) {
            return res.json({ success: false, message: "All fields are required" });
        }

        const user = await userModel.findOne({ email });

        if (!user) {
            return res.json({ success: false, message: "Invalid Credentials" });
        }

        const match = await bcrypt.compare(password, user.password)

        if (!match) {
            return res.json({ success: false, message: "Invalid Credentials" });
        }

        generateToken(res, user._id)
        return res.json({ success: true, message: "Login successfully" });

    } catch (error) {
        console.log(error);
        return res.json({ success: false, message: error.message });
    }
}

export const logout = (req, res) => {
    try {
        res.clearCookie("token");
        return res.json({ success: true, message: "Logged Out" });

    } catch (error) {
        console.log(error);
        return res.json({ success: false, message: error.message });
    }
}

export const profile = (req, res) => {
    try {
        return res.json({ success: true, user: req.user })
    } catch (error) {
        console.log(error);
        return res.json({ success: false, message: error.message });
    }
}