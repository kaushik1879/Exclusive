import React, { useEffect, useState } from "react"
import Apple from "../assets/icons/Apple.svg"
import ThinArrow from "../assets/icons/thin-arrow.svg"
import Hero1 from "../assets/images/hero-1.jpg"

const slides = [
    {
        id: 1,
        brand: "iPhone 14 Series",
        title: "Up to 10% off Voucher",
        image: Hero1,
    },
    {
        id: 2,
        brand: "iPhone 13 Series",
        title: "Up to 20% off Voucher",
        image: Hero1,
    },
    {
        id: 3,
        brand: "iPhone Accessories",
        title: "Up to 30% off Voucher",
        image: Hero1,
    },
]

const Hero = () => {
    const [current, setCurrent] = useState(0)

    // Auto slide
    useEffect(() => {
        const interval = setInterval(() => {
            setCurrent((prev) => (prev + 1) % slides.length)
        }, 4000)

        return () => clearInterval(interval)
    }, [])

    return (
        <section className="w-full px-4 md:px-0 py-8">
            <div className="relative w-full max-w-6xl mx-auto h-[320px] md:h-[400px] bg-black overflow-hidden rounded-lg">

                {/* SLIDES */}
                <div
                    className="flex transition-transform duration-700 ease-in-out h-full"
                    style={{ transform: `translateX(-${current * 100}%)` }}
                >
                    {slides.map((slide) => (
                        <div
                            key={slide.id}
                            className="w-full flex-shrink-0 px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-6 h-full"
                        >
                            {/* LEFT CONTENT */}
                            <div className="flex flex-col gap-4 max-w-sm">
                                <div className="flex items-center gap-3">
                                    <img src={Apple} alt="" className="w-8" />
                                    <p className="text-white text-lg">
                                        {slide.brand}
                                    </p>
                                </div>

                                <h4 className="text-white text-2xl md:text-4xl lg:text-5xl leading-tight">
                                    {slide.title}
                                </h4>

                                <div className="flex items-center gap-2 cursor-pointer group w-fit">
                                    <p className="text-white text-sm border-b border-white pb-0.5">
                                        Shop Now
                                    </p>
                                    <img
                                        src={ThinArrow}
                                        alt=""
                                        className="w-4 transition-transform duration-300 group-hover:translate-x-1"
                                    />
                                </div>
                            </div>

                            {/* RIGHT IMAGE */}
                            <div className="w-[300px] md:w-[400px] flex justify-center">
                                <img
                                    src={slide.image}
                                    alt=""
                                    className="w-full object-contain"
                                />
                            </div>
                        </div>
                    ))}
                </div>

                {/* DOTS */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                    {slides.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => setCurrent(index)}
                            className={`h-2 w-2 rounded-full transition ${current === index
                                    ? "bg-white"
                                    : "bg-white/40"
                                }`}
                        />
                    ))}
                </div>
            </div>
        </section>
    )
}

export default Hero