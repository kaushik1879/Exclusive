import React, { useEffect, useState } from "react"
import { NavLink, Link, useLocation } from "react-router-dom"
import { User } from "lucide-react"

import DropDown from "../assets/icons/DropDown.svg"
import Search from "../assets/icons/Search.svg"
import Heart from "../assets/icons/Heart.svg"
import Cart1 from "../assets/icons/Cart1.svg"

import useAuthStore from "../store/useAuthStore"
import useCartStore from "../store/useCartStore"

const Navbar = () => {
    const [menuOpen, setMenuOpen] = useState(false)
    const [langOpen, setLangOpen] = useState(false)
    const [profileOpen, setProfileOpen] = useState(false)

    const { user, logout } = useAuthStore()
    const location = useLocation()

    const cartCount = useCartStore(
        state => state.cart.reduce((sum, item) => sum + item.quantity, 0)
    )

    // Close dropdowns on route change
    useEffect(() => {
        setMenuOpen(false)
        setLangOpen(false)
        setProfileOpen(false)
    }, [location.pathname])
    
    return (
        <div className="sticky top-0 z-50 bg-white">

            {/* ================= TOP BLACK BAR ================= */}
            {/* <div className="w-full h-12 bg-black flex items-center justify-center px-4">
                <div className="flex items-center justify-between w-full max-w-6xl">

                    <div className="flex items-center gap-2 text-sm text-white">
                        <p className="hidden sm:block">
                            Summer Sale For All Swim Suits And Free Express Delivery - OFF 50%!
                        </p>
                        <p className="underline cursor-pointer">ShopNow</p>
                    </div>


                    <div
                        className="relative flex items-center gap-1 text-white cursor-pointer"
                        onClick={() => setLangOpen(!langOpen)}
                    >
                        <span>English</span>
                        <img
                            src={DropDown}
                            alt=""
                            className={`w-4 h-4 transition-transform ${langOpen ? "rotate-180" : ""
                                }`}
                        />

                        <div
                            className={`absolute right-0 top-8 bg-white text-black rounded shadow-md w-28 transition-all ${langOpen
                                ? "opacity-100 scale-100"
                                : "opacity-0 scale-95 pointer-events-none"
                                }`}
                        >
                            <ul className="py-2 text-sm">
                                <li className="px-4 py-2 hover:bg-gray-100">English</li>
                                <li className="px-4 py-2 hover:bg-gray-100">Hindi</li>
                                <li className="px-4 py-2 hover:bg-gray-100">French</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> */}

            {/* ================= MAIN NAVBAR ================= */}
            <div className="w-full bg-white px-4 py-4 border-b border-gray-200">
                <div className="flex items-center justify-between max-w-6xl mx-auto">

                    {/* Logo + Desktop Menu */}
                    <div className="flex items-center gap-10">
                        <h1 className="font-bold text-2xl">Exclusive</h1>

                        <ul className="hidden md:flex items-center gap-8">
                            <NavLink
                                to="/"
                                className={({ isActive }) =>
                                    isActive
                                        ? "text-black font-semibold border-b-2 border-black "
                                        : "text-gray-600 hover:text-black"
                                }
                            >
                                Home
                            </NavLink>

                            <NavLink
                                to="/contact"
                                className={({ isActive }) =>
                                    isActive
                                        ? "text-black font-semibold border-b-2 border-black "
                                        : "text-gray-600 hover:text-black"
                                }
                            >
                                Contact
                            </NavLink>

                            <NavLink
                                to="/about"
                                className={({ isActive }) =>
                                    isActive
                                        ? "text-black font-semibold border-b-2 border-black "
                                        : "text-gray-600 hover:text-black"
                                }
                            >
                                About
                            </NavLink>
                            <NavLink
                                to="/collections"
                                className={({ isActive }) =>
                                    isActive
                                        ? "text-black font-semibold border-b-2 border-black "
                                        : "text-gray-600 hover:text-black"
                                }
                            >
                                Collections
                            </NavLink>
                        </ul>
                    </div>

                    {/* Search + Icons */}
                    <div className="flex items-center gap-6">

                        {/* Search */}
                        <div className="hidden sm:flex items-center bg-gray-100 px-5 h-10 gap-3 w-64 md:w-80">
                            <input
                                type="text"
                                placeholder="What are you looking for?"
                                className="bg-transparent outline-none text-sm flex-1"
                            />
                            <img src={Search} alt="" className="w-5 h-5 opacity-70" />
                        </div>

                        {/* Icons */}
                        <div className="flex items-center gap-4">

                            <Link to="/wishlist">
                                <img src={Heart} alt="" className="w-6 h-6 cursor-pointer" />
                            </Link>

                            <Link to="/cart" className="relative">
                                <img src={Cart1} alt="" className="w-6 h-6 cursor-pointer" />
                                {cartCount > 0 && (
                                    <span className="absolute -top-3 left-2 bg-red-500 px-2 rounded-full text-white text-xs">
                                        {cartCount}
                                    </span>
                                )}
                            </Link>

                            {/* Profile */}
                            <div className="relative">
                                <div
                                    onClick={() => setProfileOpen(!profileOpen)}
                                    className="cursor-pointer"
                                >
                                    {user ? (
                                        <div className="w-9 h-9 flex items-center justify-center rounded-full bg-black text-white font-semibold text-lg hover:opacity-80 transition">
                                            {user?.name?.charAt(0).toUpperCase()}
                                        </div>
                                    ) : (
                                        <User
                                            size={24}
                                            className="hover:text-gray-600"
                                        />
                                    )}
                                </div>

                                <div
                                    className={`absolute right-0 top-10 w-40 bg-white border rounded shadow-md transition-all ${profileOpen
                                        ? "opacity-100 scale-100"
                                        : "opacity-0 scale-95 pointer-events-none"
                                        }`}
                                >
                                    <ul className="text-sm">
                                        {user ? (
                                            <>
                                                <li className="px-4 py-2 hover:bg-gray-100">
                                                    <Link to="/profile">My Profile</Link>
                                                </li>

                                                <li className="px-4 py-2 hover:bg-gray-100">
                                                    <Link to="/my-orders">My Orders</Link>
                                                </li>

                                                <li
                                                    className="px-4 py-2 hover:bg-gray-100 text-red-600 cursor-pointer"
                                                    onClick={logout}
                                                >
                                                    Logout
                                                </li>
                                            </>
                                        ) : (
                                            <>
                                                {/* <li className="px-4 py-2 hover:bg-gray-100">
                                                    <Link to="/login">Login</Link>
                                                </li> */}
                                                <li className="px-4 py-2 hover:bg-gray-100">
                                                    <Link to="/sign-up">Sign Up</Link>
                                                </li>
                                            </>
                                        )}
                                    </ul>
                                </div>
                            </div>
                        </div>

                        {/* Hamburger */}
                        <button
                            className="md:hidden w-8 h-8 relative"
                            onClick={() => setMenuOpen(!menuOpen)}
                        >
                            <span className={`block h-0.5 w-6 bg-black mb-1 ${menuOpen && "rotate-45 translate-y-1.5"}`} />
                            <span className={`block h-0.5 w-6 bg-black mb-1 ${menuOpen && "opacity-0"}`} />
                            <span className={`block h-0.5 w-6 bg-black ${menuOpen && "-rotate-45 -translate-y-1.5"}`} />
                        </button>

                    </div>
                </div>
            </div>

            {/* ================= MOBILE MENU ================= */}
            <div
                className={`md:hidden transition-all ${menuOpen ? "max-h-60 opacity-100" : "max-h-0 opacity-0"
                    } overflow-hidden`}
            >
                <ul className="flex flex-col gap-4 px-6 py-4 bg-white shadow">
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/contact">Contact</Link></li>
                    <li><Link to="/about">About</Link></li>

                    {user ? (
                        <>
                            <li><Link to="/profile">My Profile</Link></li>
                            <li><Link to="/my-orders">My Orders</Link></li>
                            <li className="text-red-600 cursor-pointer" onClick={logout}>Logout</li>
                        </>
                    ) : (
                        <>
                            <li><Link to="/login">Login</Link></li>
                            <li><Link to="/sign-up">Sign Up</Link></li>
                        </>
                    )}
                </ul>
            </div>

        </div>
    )
}

export default Navbar
