import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"

import useCartStore from "../store/useCartStore"
import useAuthStore from "../store/useAuthStore"
import useOrderStore from "../store/useOrderStore"

const PlaceOrder = () => {
    const navigate = useNavigate()

    const { cart, buyNowItem, clearCart, clearBuyNowItem } = useCartStore()
    const { user, loading: authLoading } = useAuthStore()
    const {
        placeOrder,
        loading: orderLoading,
        error,
        success,
        order,
    } = useOrderStore()

    const checkoutItems = buyNowItem ? [buyNowItem] : cart

    const [billingDetails, setBillingDetails] = useState({
        firstName: "",
        lastName: "",
        addressLine1: "",
        addressLine2: "",
        city: "",
        state: "",
        postalCode: "",
        country: "India",
        phone: "",
        email: user?.email || "",
    })

    const [formErrors, setFormErrors] = useState({})

    const paymentMethod = "COD"

    /* ---------------- AUTH GUARD ---------------- */
    useEffect(() => {
        if (!authLoading && !user) {
            navigate("/sign-up", { state: { from: "/place-order" } })
        }
    }, [user, authLoading, navigate])

    /* ---------------- CLEAR CART + REDIRECT ---------------- */
    useEffect(() => {
        if (success && order?._id) {
            if (!buyNowItem) clearCart()
            clearBuyNowItem()
            navigate(`/order-success/${order._id}`)
        }
    }, [success, order, buyNowItem, clearCart, clearBuyNowItem, navigate])

    /* ---------------- HANDLE CHANGE ---------------- */
    const handleChange = (e) => {
        setBillingDetails({
            ...billingDetails,
            [e.target.name]: e.target.value,
        })

        setFormErrors({
            ...formErrors,
            [e.target.name]: "",
        })
    }

    /* ---------------- VALIDATION ---------------- */
    const validateForm = () => {
        const errors = {}

        if (!billingDetails.firstName.trim())
            errors.firstName = "First name is required"

        if (!billingDetails.lastName.trim())
            errors.lastName = "Last name is required"

        if (!billingDetails.addressLine1.trim())
            errors.addressLine1 = "Address is required"

        if (!billingDetails.city.trim())
            errors.city = "City is required"

        if (!billingDetails.state.trim())
            errors.state = "State is required"

        if (!billingDetails.postalCode.trim())
            errors.postalCode = "Postal code is required"
        else if (!/^\d{6}$/.test(billingDetails.postalCode))
            errors.postalCode = "Invalid pincode"

        if (!billingDetails.phone.trim())
            errors.phone = "Phone number is required"
        else if (!/^[6-9]\d{9}$/.test(billingDetails.phone))
            errors.phone = "Invalid Indian phone number"

        if (!billingDetails.email.trim())
            errors.email = "Email is required"
        else if (!/^\S+@\S+\.\S+$/.test(billingDetails.email))
            errors.email = "Invalid email"

        if (checkoutItems.length === 0)
            errors.cart = "Your cart is empty"

        setFormErrors(errors)

        return Object.keys(errors).length === 0
    }

    const subtotal = checkoutItems.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
    )

    const handlePlaceOrder = () => {
        if (!validateForm()) return

        const cartItems = checkoutItems.map((item) => ({
            product: item._id,
            quantity: item.quantity,
            price: item.price,
        }))

        placeOrder({
            billingDetails,
            cartItems,
            paymentMethod,
        })
    }

    return (
        <section className="max-w-[1170px] mx-auto px-4 py-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">

                {/* ================= LEFT — BILLING ================= */}
                <div>
                    <h2 className="text-xl font-medium mb-8">Billing Details</h2>

                    <form className="space-y-6">

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <Input label="First Name*" name="firstName" value={billingDetails.firstName} onChange={handleChange} error={formErrors.firstName} />
                            <Input label="Last Name*" name="lastName" value={billingDetails.lastName} onChange={handleChange} error={formErrors.lastName} />
                        </div>

                        <Input label="Street Address*" name="addressLine1" value={billingDetails.addressLine1} onChange={handleChange} error={formErrors.addressLine1} />

                        <Input label="Apartment / Landmark (optional)" name="addressLine2" value={billingDetails.addressLine2} onChange={handleChange} />

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                            <Input label="City*" name="city" value={billingDetails.city} onChange={handleChange} error={formErrors.city} />
                            <Input label="State*" name="state" value={billingDetails.state} onChange={handleChange} error={formErrors.state} />
                            <Input label="Postal Code*" name="postalCode" value={billingDetails.postalCode} onChange={handleChange} error={formErrors.postalCode} />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <Input label="Phone*" name="phone" value={billingDetails.phone} onChange={handleChange} error={formErrors.phone} />
                            <Input label="Email*" name="email" value={billingDetails.email} onChange={handleChange} error={formErrors.email} />
                        </div>

                        {formErrors.cart && (
                            <p className="text-red-500 text-sm">{formErrors.cart}</p>
                        )}
                    </form>
                </div>

                {/* ================= RIGHT — YOUR ORIGINAL UI ================= */}
                <div className="space-y-6">

                    <div className="space-y-4">
                        {checkoutItems.map((item) => (
                            <div key={item._id} className="flex justify-between items-center">
                                <div className="flex items-center gap-4">
                                    <img
                                        src={item.image}
                                        alt=""
                                        className="w-12 h-12 object-contain"
                                    />
                                    <p>
                                        {item.title} × {item.quantity}
                                    </p>
                                </div>
                                <span>₹{item.price * item.quantity}</span>
                            </div>
                        ))}
                    </div>

                    <hr />

                    <div className="space-y-3">
                        <Row label="Subtotal" value={`₹${subtotal}`} />
                        <Row label="Shipping" value="Free" />
                        <Row label="Total" value={`₹${subtotal}`} bold />
                    </div>

                    <div className="space-y-3">
                        <label className="flex items-center gap-3">
                            <input type="radio" disabled />
                            Bank (Coming Soon)
                        </label>
                        <label className="flex items-center gap-3">
                            <input type="radio" defaultChecked />
                            Cash on Delivery
                        </label>
                    </div>

                    {error && <p className="text-red-500 text-sm">{error}</p>}

                    <button
                        onClick={handlePlaceOrder}
                        disabled={orderLoading}
                        className="w-[200px] h-[56px] bg-[#DB4444] text-white rounded hover:opacity-90"
                    >
                        {orderLoading ? "Placing Order..." : "Place Order"}
                    </button>
                </div>
            </div>
        </section>
    )
}

const Input = ({ label, name, value, onChange, error }) => (
    <div>
        <label className="block text-sm mb-2">{label}</label>
        <input
            name={name}
            value={value}
            onChange={onChange}
            className={`w-full h-[52px] bg-[#F5F5F5] px-4 rounded outline-none 
                ${error ? "border border-red-500 bg-red-50" : ""}`}
        />
        {error && (
            <p className="text-red-500 text-xs mt-1">{error}</p>
        )}
    </div>
)

const Row = ({ label, value, bold }) => (
    <div className={`flex justify-between ${bold ? "font-medium" : ""}`}>
        <span>{label}</span>
        <span>{value}</span>
    </div>
)

export default PlaceOrder
